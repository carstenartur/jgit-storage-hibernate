/*
 * Copyright (C) 2026, Carsten Hammer and contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the BSD 3-Clause License.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
package io.github.carstenartur.jgit.storage.hibernate.spring;

/** Marker type for the dependency-only Spring Boot starter artifact. */
public final class JgitStorageHibernateSpringBootStarter {

  private JgitStorageHibernateSpringBootStarter() {}
}
