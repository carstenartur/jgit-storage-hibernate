/*
 * Copyright (C) 2026, Carsten Hammer and contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the BSD 3-Clause License.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
package io.github.carstenartur.jgit.storage.hibernate.search.service;

import io.github.carstenartur.jgit.storage.hibernate.search.entity.GitCommitIndex;
import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.search.engine.search.common.BooleanOperator;
import org.hibernate.search.mapper.orm.Search;
import org.hibernate.search.mapper.orm.session.SearchSession;

/** Query service for indexed Git history. */
public class GitHistorySearchService {

  private final SessionFactory sessionFactory;

  public GitHistorySearchService(SessionFactory sessionFactory) {
    this.sessionFactory = Objects.requireNonNull(sessionFactory, "sessionFactory");
  }

  public List<GitCommitIndex> searchCommitText(String repositoryName, String query, int limit) {
    return findChanges(
        CommitHistoryQuery.forRepository(repositoryName)
            .matchingText(query)
            .limit(limit)
            .build());
  }

  /**
   * Find commits matching all supplied full-text, author, changed-path, time and candidate predicates.
   *
   * <p>Results are relevance-ranked when full text is present and newest-first otherwise. The
   * chronological dimension is selected by {@link CommitHistoryQuery#timestampField()} and defaults
   * to committer time.
   */
  public List<GitCommitIndex> findChanges(CommitHistoryQuery query) {
    Objects.requireNonNull(query, "query");
    if (query.hasObjectIdRestriction() && query.objectIds().isEmpty()) {
      return List.of();
    }
    return query.text() == null ? findStructuredChanges(query) : findFullTextChanges(query);
  }

  private List<GitCommitIndex> findFullTextChanges(CommitHistoryQuery query) {
    String timeField = searchTimeField(query);
    try (Session session = sessionFactory.openSession()) {
      SearchSession searchSession = Search.session(session);
      return searchSession
          .search(GitCommitIndex.class)
          .where(
              f -> {
                var predicate =
                    f.bool()
                        .filter(
                            f.match()
                                .field("repositoryName")
                                .matching(query.repositoryName()))
                        .must(
                            f.simpleQueryString()
                                .fields(
                                    "shortMessage",
                                    "fullMessage",
                                    "changedPaths",
                                    "changedText")
                                .matching(query.text()));
                if (query.hasObjectIdRestriction()) {
                  predicate.filter(f.terms().field("objectId").matchingAny(query.objectIds()));
                }
                if (query.authorEmail() != null) {
                  predicate.filter(f.match().field("authorEmail").matching(query.authorEmail()));
                }
                if (query.pathFragment() != null) {
                  predicate.filter(
                      f.simpleQueryString()
                          .field(GitCommitIndex.CHANGED_PATH_TERMS_FIELD)
                          .matching(query.pathFragment())
                          .defaultOperator(BooleanOperator.AND));
                }
                if (query.from() != null) {
                  predicate.filter(f.range().field(timeField).atLeast(query.from()));
                }
                if (query.to() != null) {
                  predicate.filter(f.range().field(timeField).atMost(query.to()));
                }
                return predicate;
              })
          .fetchHits(query.limit());
    }
  }

  private List<GitCommitIndex> findStructuredChanges(CommitHistoryQuery query) {
    String timeProperty = hqlTimeProperty(query);
    StringBuilder hql =
        new StringBuilder("FROM GitCommitIndex c WHERE c.repositoryName = :repo");
    if (query.hasObjectIdRestriction()) {
      hql.append(" AND c.objectId IN :objectIds");
    }
    if (query.authorEmail() != null) {
      hql.append(" AND c.authorEmail = :email");
    }
    if (query.pathFragment() != null) {
      hql.append(" AND LOWER(c.changedPaths) LIKE :path ESCAPE '!'");
    }
    if (query.from() != null) {
      hql.append(" AND c.").append(timeProperty).append(" >= :from");
    }
    if (query.to() != null) {
      hql.append(" AND c.").append(timeProperty).append(" <= :to");
    }
    hql.append(" ORDER BY c.").append(timeProperty).append(" DESC");

    try (Session session = sessionFactory.openSession()) {
      var selection =
          session
              .createQuery(hql.toString(), GitCommitIndex.class)
              .setParameter("repo", query.repositoryName())
              .setMaxResults(query.limit());
      if (query.hasObjectIdRestriction()) {
        selection.setParameter("objectIds", query.objectIds());
      }
      if (query.authorEmail() != null) {
        selection.setParameter("email", query.authorEmail());
      }
      if (query.pathFragment() != null) {
        selection.setParameter(
            "path", "%" + escapeLikePattern(query.pathFragment().toLowerCase(Locale.ROOT)) + "%");
      }
      if (query.from() != null) {
        selection.setParameter("from", query.from());
      }
      if (query.to() != null) {
        selection.setParameter("to", query.to());
      }
      return selection.getResultList();
    }
  }

  private static String hqlTimeProperty(CommitHistoryQuery query) {
    return query.timestampField() == CommitHistoryQuery.TimestampField.AUTHOR
        ? "authorTime"
        : "committerTime";
  }

  private static String searchTimeField(CommitHistoryQuery query) {
    return hqlTimeProperty(query);
  }

  public List<GitCommitIndex> findByPath(String repositoryName, String pathFragment, int limit) {
    return findChanges(
        CommitHistoryQuery.forRepository(repositoryName)
            .touchingPath(pathFragment)
            .limit(limit)
            .build());
  }

  public List<GitCommitIndex> findByAuthorEmail(
      String repositoryName, String authorEmail, int limit) {
    return findChanges(
        CommitHistoryQuery.forRepository(repositoryName)
            .authoredBy(authorEmail)
            .limit(limit)
            .build());
  }

  /** Return commits whose committer timestamps are in the inclusive range. */
  public List<GitCommitIndex> findBetween(
      String repositoryName, Instant from, Instant to, int limit) {
    return findChanges(
        CommitHistoryQuery.forRepository(repositoryName)
            .committedBetween(from, to)
            .limit(limit)
            .build());
  }

  /** Return commits whose author timestamps are in the inclusive range. */
  public List<GitCommitIndex> findAuthoredBetween(
      String repositoryName, Instant from, Instant to, int limit) {
    return findChanges(
        CommitHistoryQuery.forRepository(repositoryName)
            .authoredBetween(from, to)
            .limit(limit)
            .build());
  }

  public long countIndexedCommits(String repositoryName) {
    try (Session session = sessionFactory.openSession()) {
      Long count =
          session
              .createQuery(
                  "SELECT COUNT(c) FROM GitCommitIndex c WHERE c.repositoryName = :repo", Long.class)
              .setParameter("repo", repositoryName)
              .uniqueResult();
      return count != null ? count.longValue() : 0L;
    }
  }

  private static String escapeLikePattern(String value) {
    return value.replace("!", "!!").replace("%", "!%").replace("_", "!_");
  }
}
