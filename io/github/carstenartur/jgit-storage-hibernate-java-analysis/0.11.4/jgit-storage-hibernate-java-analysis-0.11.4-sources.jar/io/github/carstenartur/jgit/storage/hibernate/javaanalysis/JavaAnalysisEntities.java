/*
 * Copyright (C) 2026, Carsten Hammer and contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the BSD 3-Clause License.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
package io.github.carstenartur.jgit.storage.hibernate.javaanalysis;

import io.github.carstenartur.jgit.storage.hibernate.javaanalysis.entity.JavaAnalysisRun;
import io.github.carstenartur.jgit.storage.hibernate.javaanalysis.entity.JavaGraphEdgeIndex;
import io.github.carstenartur.jgit.storage.hibernate.javaanalysis.entity.JavaProjectionState;
import io.github.carstenartur.jgit.storage.hibernate.javaanalysis.entity.JavaReferenceIndex;
import io.github.carstenartur.jgit.storage.hibernate.javaanalysis.entity.JavaSymbolIndex;
import java.util.List;

/**
 * Incubating entity registration helper for controlled Java-analysis persistence experiments.
 *
 * <p>The {@code 0.1.x} module does not yet ship Flyway migrations, a projection writer/rebuilder or
 * repository-deletion integration for these mappings. Applications registering them must own and
 * test the complete schema and lifecycle; the supported default is to use analysis DTOs in memory.
 */
public final class JavaAnalysisEntities {

  private JavaAnalysisEntities() {}

  public static List<Class<?>> annotatedClasses() {
    return List.of(
        JavaAnalysisRun.class,
        JavaProjectionState.class,
        JavaSymbolIndex.class,
        JavaReferenceIndex.class,
        JavaGraphEdgeIndex.class);
  }
}
