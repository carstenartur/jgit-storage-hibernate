package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class LargePackJdbcBatchBenchmark_jmhType extends LargePackJdbcBatchBenchmark_jmhType_B3 {
}

