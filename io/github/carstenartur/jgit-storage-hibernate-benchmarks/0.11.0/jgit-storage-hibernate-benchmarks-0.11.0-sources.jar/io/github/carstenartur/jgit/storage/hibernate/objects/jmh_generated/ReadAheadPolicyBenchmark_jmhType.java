package io.github.carstenartur.jgit.storage.hibernate.objects.jmh_generated;
public class ReadAheadPolicyBenchmark_jmhType extends ReadAheadPolicyBenchmark_jmhType_B3 {
}

