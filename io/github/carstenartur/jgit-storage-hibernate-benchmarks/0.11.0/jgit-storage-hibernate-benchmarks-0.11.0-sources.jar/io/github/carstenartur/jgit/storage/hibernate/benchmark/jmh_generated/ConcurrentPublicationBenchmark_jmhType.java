package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class ConcurrentPublicationBenchmark_jmhType extends ConcurrentPublicationBenchmark_jmhType_B3 {
}

