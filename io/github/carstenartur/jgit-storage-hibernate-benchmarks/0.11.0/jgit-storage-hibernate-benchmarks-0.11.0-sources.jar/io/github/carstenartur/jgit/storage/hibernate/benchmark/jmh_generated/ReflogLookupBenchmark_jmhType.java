package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class ReflogLookupBenchmark_jmhType extends ReflogLookupBenchmark_jmhType_B3 {
}

