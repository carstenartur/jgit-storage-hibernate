package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class ReflogLookupBenchmark_ReflogCounters_jmhType extends ReflogLookupBenchmark_ReflogCounters_jmhType_B3 {
}

