package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class RepositoryAgingBenchmark_jmhType extends RepositoryAgingBenchmark_jmhType_B3 {
}

