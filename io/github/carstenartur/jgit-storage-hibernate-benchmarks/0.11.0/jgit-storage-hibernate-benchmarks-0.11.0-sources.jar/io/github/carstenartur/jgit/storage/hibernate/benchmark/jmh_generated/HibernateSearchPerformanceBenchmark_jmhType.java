package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class HibernateSearchPerformanceBenchmark_jmhType extends HibernateSearchPerformanceBenchmark_jmhType_B3 {
}

