package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class DurableWriteQueueBenchmark_jmhType extends DurableWriteQueueBenchmark_jmhType_B3 {
}

