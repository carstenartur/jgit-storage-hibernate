package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class GitProtocolBenchmark_jmhType extends GitProtocolBenchmark_jmhType_B3 {
}

