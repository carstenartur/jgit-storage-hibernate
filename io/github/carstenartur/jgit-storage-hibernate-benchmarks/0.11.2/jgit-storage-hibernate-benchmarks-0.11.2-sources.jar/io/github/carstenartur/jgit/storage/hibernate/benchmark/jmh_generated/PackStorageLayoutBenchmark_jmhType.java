package io.github.carstenartur.jgit.storage.hibernate.benchmark.jmh_generated;
public class PackStorageLayoutBenchmark_jmhType extends PackStorageLayoutBenchmark_jmhType_B3 {
}

