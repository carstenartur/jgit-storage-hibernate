/*
 * Copyright (C) 2026, Carsten Hammer and contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the BSD 3-Clause License.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
package io.github.carstenartur.jgit.storage.hibernate.objects;

import io.github.carstenartur.jgit.storage.hibernate.config.HibernateStorageSettings;
import io.github.carstenartur.jgit.storage.hibernate.entity.GitPackChunkEntity;
import io.github.carstenartur.jgit.storage.hibernate.entity.GitPackEntity;
import io.github.carstenartur.jgit.storage.hibernate.objects.PackExtensionStagingBuffer.StagedPayload;
import io.github.carstenartur.jgit.storage.hibernate.objects.PackExtensionStagingBuffer.StagedPayloadReader;
import io.github.carstenartur.jgit.storage.hibernate.transaction.HibernateTransactionContext;
import io.github.carstenartur.jgit.storage.hibernate.transaction.PackPublicationPolicySnapshot;
import io.github.carstenartur.jgit.storage.hibernate.transaction.PackPublicationPolicySnapshot.Reason;
import io.github.carstenartur.jgit.storage.hibernate.transaction.StorageOperationKind;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.LongConsumer;
import org.eclipse.jgit.internal.storage.dfs.DfsOutputStream;
import org.eclipse.jgit.internal.storage.dfs.DfsPackDescription;
import org.eclipse.jgit.internal.storage.pack.PackExt;
import org.hibernate.Session;
import org.hibernate.exception.ConstraintViolationException;

/**
 * JVM-local staging for unpublished DFS pack extensions.
 *
 * <p>JGit may read data back through an open {@link DfsOutputStream} while it parses or builds an
 * extension. Closing the stream retains the completed bytes in bounded memory or a temporary file
 * and creates no database row. Extensions spill once after the 256-KiB staging-memory limit or the
 * process budget is exhausted.
 *
 * <p>Additive logical packs whose extensions all remain inline use one repository-locked
 * transaction for persistence and publication. The default also uses that path for chunked packs
 * below one MiB of total staged payload. The optional contention policy can lower that threshold.
 * Eligible packs selected for pre-persistence are written as a complete invisible lease-owned
 * generation before acquiring the repository lock to publish them atomically. Readers continue to
 * select only {@code committed=true} rows.
 *
 * <p>Pack replacement and compaction remain on the established single locked transaction path. JGit
 * can validate refs before calling {@code commitPack}; releasing the repository lock between that
 * validation and source-pack replacement would permit a conflicting ref update to cross the race
 * check.
 *
 * <p>A crash after pre-persistence can leave a complete durable uncommitted group. Its shared
 * writer token and renewed lease make it eligible for the existing abandoned-write cleanup after
 * expiry. Normal publication, failure handling and rollback remove it explicitly. Local temporary
 * files remain derived unpublished state and are never imported as durable Git data.
 */
final class StagedPackExtensionStore {

  private static final int CHUNK_BATCH_SIZE = 8;
  static final long DEFAULT_PREPERSIST_MIN_PAYLOAD_BYTES =
      HibernateStorageSettings.DEFAULT_PREPERSIST_MIN_PAYLOAD_BYTES;
  private static final String PACK_EXTENSION_UNIQUE_CONSTRAINT = "uk_pack_repo_name_ext";
  private static final PrePublicationHook NO_PRE_PUBLICATION_HOOK = ignored -> {};

  private final String repositoryName;
  private final HibernateTransactionContext transactionContext;
  private final PrePublicationHook prePublicationHook;
  private final PackPublicationSelector publicationSelector;
  private final StorageByteCounters storageByteCounters;
  private final PackPublicationSelectionCounters publicationSelectionCounters;
  private final Map<ExtensionKey, StagedExtension> staged = new ConcurrentHashMap<>();
  private final Map<String, String> preparedTokensByPackName = new ConcurrentHashMap<>();

  StagedPackExtensionStore(
      String repositoryName, HibernateTransactionContext transactionContext) {
    this(
        repositoryName,
        transactionContext,
        NO_PRE_PUBLICATION_HOOK,
        DEFAULT_PREPERSIST_MIN_PAYLOAD_BYTES,
        StorageByteCounters.disabled());
  }

  StagedPackExtensionStore(
      String repositoryName,
      HibernateTransactionContext transactionContext,
      StorageByteCounters storageByteCounters) {
    this(
        repositoryName,
        transactionContext,
        NO_PRE_PUBLICATION_HOOK,
        DEFAULT_PREPERSIST_MIN_PAYLOAD_BYTES,
        storageByteCounters);
  }

  StagedPackExtensionStore(
      String repositoryName,
      HibernateTransactionContext transactionContext,
      StorageByteCounters storageByteCounters,
      PackPublicationSelector publicationSelector) {
    this(
        repositoryName,
        transactionContext,
        NO_PRE_PUBLICATION_HOOK,
        storageByteCounters,
        publicationSelector);
  }

  StagedPackExtensionStore(
      String repositoryName,
      HibernateTransactionContext transactionContext,
      PrePublicationHook prePublicationHook) {
    this(
        repositoryName,
        transactionContext,
        prePublicationHook,
        PackPublicationSelector.MIN_PREPERSIST_PAYLOAD_BYTES,
        StorageByteCounters.disabled());
  }

  StagedPackExtensionStore(
      String repositoryName,
      HibernateTransactionContext transactionContext,
      PrePublicationHook prePublicationHook,
      long minimumPrePersistedPayloadBytes) {
    this(
        repositoryName,
        transactionContext,
        prePublicationHook,
        minimumPrePersistedPayloadBytes,
        StorageByteCounters.disabled());
  }

  StagedPackExtensionStore(
      String repositoryName,
      HibernateTransactionContext transactionContext,
      PrePublicationHook prePublicationHook,
      long minimumPrePersistedPayloadBytes,
      StorageByteCounters storageByteCounters) {
    this(
        repositoryName,
        transactionContext,
        prePublicationHook,
        storageByteCounters,
        new PackPublicationSelector(
            HibernateStorageSettings.SIZE_PUBLICATION_SELECTOR,
            storageByteCounters.enabled(),
            minimumPrePersistedPayloadBytes,
            null));
  }

  private StagedPackExtensionStore(
      String repositoryName,
      HibernateTransactionContext transactionContext,
      PrePublicationHook prePublicationHook,
      StorageByteCounters storageByteCounters,
      PackPublicationSelector publicationSelector) {
    this.repositoryName = Objects.requireNonNull(repositoryName, "repositoryName");
    this.transactionContext = Objects.requireNonNull(transactionContext, "transactionContext");
    this.prePublicationHook = Objects.requireNonNull(prePublicationHook, "prePublicationHook");
    this.publicationSelector = Objects.requireNonNull(publicationSelector, "publicationSelector");
    this.storageByteCounters = Objects.requireNonNull(storageByteCounters, "storageByteCounters");
    this.publicationSelectionCounters = PackPublicationSelectionCounters.from(storageByteCounters);
  }

  DfsOutputStream open(DfsPackDescription description, PackExt extension) throws IOException {
    String packName = baseName(description);
    ExtensionKey key = new ExtensionKey(packName, extension.getExtension());
    if (staged.containsKey(key)) {
      throw new IOException("Pack extension is already staged: " + key.displayName());
    }
    return new PackExtensionStagingBuffer(
        storageByteCounters,
        (payload, fileSize, createdAt) ->
            register(new StagedExtension(key, payload, fileSize, createdAt)));
  }

  CommitResult commit(
      Collection<DfsPackDescription> descriptions, Collection<DfsPackDescription> replaces)
      throws IOException {
    return commit(
        descriptions,
        replaces,
        (work, observer) ->
            transactionContext.executeWithRepositoryLock(
                StorageOperationKind.PACK_PUBLICATION, repositoryName, work, observer));
  }

  CommitResult commit(
      Collection<DfsPackDescription> descriptions,
      Collection<DfsPackDescription> replaces,
      PublicationTransaction transaction)
      throws IOException {
    List<Publication> publications = publications(descriptions);
    Reason exclusion = prePersistenceExclusion(publications, replaces);
    long payloadBytes =
        exclusion == null || storageByteCounters.enabled() ? stagedPayloadBytes(publications) : 0;
    boolean observe = exclusion == null && publicationSelector.adaptive();
    boolean nested = observe && transactionContext.hasActiveTransaction();
    try (var observation =
        observe && !nested ? publicationSelector.begin(payloadBytes, System.nanoTime()) : null) {
      boolean prePersisted =
          publicationSelector.prePersist(exclusion, payloadBytes, nested, observation);
      publicationSelectionCounters.record(prePersisted, payloadBytes);
      PublicationTransaction selectedTransaction =
          observation == null ? transaction : observeLock(transaction, observation);
      CommitResult result =
          prePersisted
              ? commitPrePersisted(publications, selectedTransaction)
              : commitDirect(publications, replaces, selectedTransaction);
      if (observation != null) {
        observation.committed(System.nanoTime());
      }
      discard(publications);
      return result;
    }
  }

  private static PublicationTransaction observeLock(
      PublicationTransaction transaction, PackPublicationSelector.Observation observation) {
    return (work, ignored) -> {
      observation.beforeLock();
      try {
        return transaction.execute(work, observation::lockAcquired);
      } finally {
        observation.afterLock();
      }
    };
  }

  private CommitResult commitDirect(
      List<Publication> publications,
      Collection<DfsPackDescription> replaces,
      PublicationTransaction transaction)
      throws IOException {
    CommitResult result =
        transaction.execute(
            session -> {
              deletePackRows(session, packNames(replaces));

              List<CommittedExtension> committed = new ArrayList<>();
              boolean completeMetadata = true;
              Instant committedAt = Instant.now();
              for (Publication publication : publications) {
                PackDescriptionMetadata metadata =
                    PackDescriptionMetadata.fromDescription(
                        publication.description(), committedAt);
                for (ExpectedExtension expected : publication.extensions()) {
                  if (expected.staged() != null) {
                    committed.add(
                        persistCommitted(session, expected.staged(), committedAt, metadata));
                  } else {
                    publishLegacyExtension(
                        session,
                        publication.packName(),
                        expected.extension(),
                        committedAt,
                        metadata);
                    completeMetadata = false;
                  }
                }
              }
              return new CommitResult(List.copyOf(committed), completeMetadata);
            });
    storageByteCounters.recordDatabasePayloadBytesWritten(
        committedPayloadBytes(result.committedExtensions()));
    return result;
  }

  private CommitResult commitPrePersisted(
      List<Publication> publications, PublicationTransaction transaction) throws IOException {
    Instant preparedAt = Instant.now();
    String writeToken = UUID.randomUUID().toString();
    Set<String> preparedPackNames = publicationPackNames(publications);
    List<PersistedExtension> persisted =
        persistPreparedPayloads(publications, writeToken, preparedAt);
    storageByteCounters.recordDatabasePayloadBytesWritten(persistedPayloadBytes(persisted));
    for (String packName : preparedPackNames) {
      preparedTokensByPackName.put(packName, writeToken);
    }

    try {
      prePublicationHook.afterPayloadPersisted(writeToken);
      CommitResult result = publishPrepared(persisted, writeToken, Instant.now(), transaction);
      clearPreparedMappings(preparedPackNames, writeToken);
      return result;
    } catch (IOException | RuntimeException failure) {
      if (cleanupPrepared(writeToken, failure)) {
        clearPreparedMappings(preparedPackNames, writeToken);
      }
      throw failure;
    }
  }

  private List<PersistedExtension> persistPreparedPayloads(
      List<Publication> publications, String writeToken, Instant preparedAt) throws IOException {
    return transactionContext.execute(
        StorageOperationKind.PACK_EXTENSION_WRITE,
        session -> {
          List<PersistedExtension> persisted = new ArrayList<>();
          Instant initialLeaseUntil = preparedAt.plus(HibernateObjDatabase.PACK_WRITE_LEASE);
          for (Publication publication : publications) {
            PackDescriptionMetadata metadata =
                PackDescriptionMetadata.fromDescription(publication.description(), preparedAt);
            for (ExpectedExtension expected : publication.extensions()) {
              StagedExtension stagedExtension =
                  Objects.requireNonNull(
                      expected.staged(), "pre-persisted extensions must be locally staged");
              boolean inline =
                  stagedExtension.fileSize() <= HibernateObjDatabase.INLINE_PAYLOAD_THRESHOLD;
              byte[] inlineData = inline ? stagedExtension.inlineData() : null;
              GitPackEntity entity = new GitPackEntity();
              entity.setRepositoryName(repositoryName);
              entity.setPackName(stagedExtension.key().packName());
              entity.setPackExtension(stagedExtension.key().extension());
              entity.setFileSize(stagedExtension.fileSize());
              entity.setCommitted(false);
              entity.setCreatedAt(stagedExtension.createdAt());
              entity.setCommittedAt(null);
              entity.setWriteToken(writeToken);
              entity.setWriteLeaseUntil(initialLeaseUntil);
              entity.setData(inlineData);
              metadata.applyTo(entity);

              try {
                session.persist(entity);
                session.flush();
                if (!inline) {
                  persistChunks(session, entity.getId(), stagedExtension);
                }
              } catch (RuntimeException exception) {
                if (isDuplicatePackExtension(exception)) {
                  throw new IOException(
                      "Pack extension already exists: "
                          + stagedExtension.key().displayName(),
                      exception);
                }
                throw exception;
              }
              persisted.add(
                  new PersistedExtension(
                      stagedExtension, entity.getId(), inline, inlineData, metadata));
            }
          }

          session.clear();
          Instant leaseUntil = Instant.now().plus(HibernateObjDatabase.PACK_WRITE_LEASE);
          int renewed =
              session
                  .createMutationQuery(
                      "UPDATE GitPackEntity p SET p.writeLeaseUntil = :leaseUntil "
                          + "WHERE p.repositoryName = :repo AND p.writeToken = :writeToken "
                          + "AND p.committed = false")
                  .setParameter("leaseUntil", leaseUntil)
                  .setParameter("repo", repositoryName)
                  .setParameter("writeToken", writeToken)
                  .executeUpdate();
          if (renewed != persisted.size()) {
            throw new IOException(
                "Prepared pack persistence expected "
                    + persisted.size()
                    + " extensions but renewed "
                    + renewed
                    + " for "
                    + repositoryName);
          }
          return List.copyOf(persisted);
        });
  }

  private CommitResult publishPrepared(
      List<PersistedExtension> persisted,
      String writeToken,
      Instant committedAt,
      PublicationTransaction transaction)
      throws IOException {
    return transaction.execute(
        session -> {
          int updated =
              session
                  .createMutationQuery(
                      "UPDATE GitPackEntity p SET p.committed = true, "
                          + "p.committedAt = :committedAt, p.writeToken = null, "
                          + "p.writeLeaseUntil = null WHERE p.repositoryName = :repo "
                          + "AND p.writeToken = :writeToken AND p.committed = false")
                  .setParameter("committedAt", committedAt)
                  .setParameter("repo", repositoryName)
                  .setParameter("writeToken", writeToken)
                  .executeUpdate();
          if (updated != persisted.size()) {
            throw new IOException(
                "Prepared pack publication expected "
                    + persisted.size()
                    + " extensions but updated "
                    + updated
                    + " for "
                    + repositoryName);
          }

          List<CommittedExtension> committed = new ArrayList<>(persisted.size());
          for (PersistedExtension extension : persisted) {
            StagedExtension stagedExtension = extension.staged();
            committed.add(
                new CommittedExtension(
                    stagedExtension.key().packName(),
                    stagedExtension.key().extension(),
                    extension.packId(),
                    stagedExtension.fileSize(),
                    extension.inline(),
                    extension.inlineData(),
                    extension.metadata()));
          }
          return new CommitResult(List.copyOf(committed), true);
        });
  }

  private boolean cleanupPrepared(String writeToken, Exception originalFailure) {
    try {
      transactionContext.execute(
          StorageOperationKind.PACK_ROLLBACK,
          session -> {
            deletePreparedRows(session, Set.of(writeToken));
            return null;
          });
      return true;
    } catch (IOException | RuntimeException cleanupFailure) {
      originalFailure.addSuppressed(cleanupFailure);
      return false;
    }
  }

  void rollback(Collection<DfsPackDescription> descriptions) {
    List<String> databasePackNames = new ArrayList<>();
    Set<String> preparedTokens = new LinkedHashSet<>();
    for (DfsPackDescription description : descriptions) {
      String packName = baseName(description);
      String preparedToken = preparedTokensByPackName.remove(packName);
      if (preparedToken != null) {
        preparedTokens.add(preparedToken);
      }

      int removedExtensions = 0;
      boolean hasUnstagedExpectedExtension = false;
      for (PackExt extension : PackExt.values()) {
        if (!description.hasFileExt(extension)) {
          continue;
        }
        ExtensionKey key = new ExtensionKey(packName, extension.getExtension());
        StagedExtension removed = staged.remove(key);
        if (removed == null) {
          hasUnstagedExpectedExtension = true;
        } else {
          removedExtensions++;
          removed.discard();
        }
      }

      for (Map.Entry<ExtensionKey, StagedExtension> entry : List.copyOf(staged.entrySet())) {
        if (entry.getKey().packName().equals(packName)
            && staged.remove(entry.getKey(), entry.getValue())) {
          removedExtensions++;
          entry.getValue().discard();
        }
      }

      if (preparedToken == null && (hasUnstagedExpectedExtension || removedExtensions == 0)) {
        databasePackNames.add(packName);
      }
    }

    if (!preparedTokens.isEmpty()) {
      try {
        transactionContext.execute(
            StorageOperationKind.PACK_ROLLBACK,
            session -> {
              deletePreparedRows(session, preparedTokens);
              return null;
            });
      } catch (IOException | RuntimeException ignored) {
        // Rollback is best-effort and must not mask the original JGit exception.
      }
    }

    if (databasePackNames.isEmpty()) {
      return;
    }

    try {
      transactionContext.executeWithRepositoryLock(
          StorageOperationKind.PACK_ROLLBACK,
          repositoryName,
          session -> {
            deletePackRows(session, databasePackNames);
            return null;
          });
    } catch (IOException | RuntimeException ignored) {
      // Rollback is best-effort and must not mask the original JGit exception.
    }
  }

  int stagedExtensionCount() {
    return staged.size();
  }

  int stagedMemoryExtensionCount() {
    return (int) staged.values().stream().filter(StagedExtension::memoryBacked).count();
  }

  int stagedFileExtensionCount() {
    return (int) staged.values().stream().filter(extension -> !extension.memoryBacked()).count();
  }

  long stagedMemoryBytes() {
    return staged.values().stream()
        .filter(StagedExtension::memoryBacked)
        .mapToLong(StagedExtension::fileSize)
        .sum();
  }

  io.github.carstenartur.jgit.storage.hibernate.transaction.StorageByteMetrics
      storageByteMetricsSnapshot() {
    return storageByteCounters.snapshot();
  }

  io.github.carstenartur.jgit.storage.hibernate.transaction.StagingSpillMetrics
      stagingSpillMetricsSnapshot() {
    return storageByteCounters.stagingSpillSnapshot();
  }

  io.github.carstenartur.jgit.storage.hibernate.transaction.PackPublicationSelectionMetrics
      publicationSelectionMetricsSnapshot() {
    return publicationSelectionCounters.snapshot();
  }

  long minimumPrePersistedPayloadBytes() {
    return publicationSelector.sizeThreshold();
  }

  PackPublicationPolicySnapshot publicationPolicySnapshot() {
    return publicationSelector.snapshot(System.nanoTime());
  }

  private void register(StagedExtension extension) throws IOException {
    StagedExtension previous = staged.putIfAbsent(extension.key(), extension);
    if (previous != null) {
      throw new IOException("Pack extension is already staged: " + extension.key().displayName());
    }
  }

  private List<Publication> publications(Collection<DfsPackDescription> descriptions)
      throws IOException {
    List<Publication> result = new ArrayList<>();
    for (DfsPackDescription description : descriptions) {
      String packName = baseName(description);
      List<ExpectedExtension> extensions = new ArrayList<>();
      for (PackExt extension : PackExt.values()) {
        if (description.hasFileExt(extension)) {
          ExtensionKey key = new ExtensionKey(packName, extension.getExtension());
          extensions.add(new ExpectedExtension(extension.getExtension(), staged.get(key)));
        }
      }
      if (extensions.isEmpty()) {
        throw new IOException("Cannot publish a pack without extensions: " + packName);
      }
      result.add(new Publication(packName, description, List.copyOf(extensions)));
    }
    return result;
  }

  private static Reason prePersistenceExclusion(
      List<Publication> publications, Collection<DfsPackDescription> replaces) {
    if (replaces != null && !replaces.isEmpty()) {
      return Reason.REPLACEMENT;
    }
    boolean chunked = false;
    for (Publication publication : publications) {
      for (ExpectedExtension expected : publication.extensions()) {
        if (expected.staged() == null) {
          return Reason.LEGACY_OR_MIXED;
        }
        if (expected.staged().fileSize() > HibernateObjDatabase.INLINE_PAYLOAD_THRESHOLD) {
          chunked = true;
        }
      }
    }
    return chunked ? null : Reason.INLINE;
  }

  private static long saturatingAdd(long left, long right) {
    if (right > Long.MAX_VALUE - left) {
      return Long.MAX_VALUE;
    }
    return left + right;
  }

  private static Set<String> publicationPackNames(List<Publication> publications) {
    Set<String> names = new LinkedHashSet<>();
    for (Publication publication : publications) {
      names.add(publication.packName());
    }
    return Set.copyOf(names);
  }

  private static Set<String> packNames(Collection<DfsPackDescription> descriptions) {
    if (descriptions == null || descriptions.isEmpty()) {
      return Set.of();
    }
    Set<String> names = new LinkedHashSet<>();
    for (DfsPackDescription description : descriptions) {
      names.add(baseName(description));
    }
    return Set.copyOf(names);
  }

  private void clearPreparedMappings(Set<String> packNames, String writeToken) {
    for (String packName : packNames) {
      preparedTokensByPackName.remove(packName, writeToken);
    }
  }

  private void discard(List<Publication> publications) {
    for (Publication publication : publications) {
      for (ExpectedExtension expected : publication.extensions()) {
        StagedExtension extension = expected.staged();
        if (extension != null) {
          staged.remove(extension.key(), extension);
          extension.discard();
        }
      }
    }
  }

  private CommittedExtension persistCommitted(
      Session session,
      StagedExtension stagedExtension,
      Instant committedAt,
      PackDescriptionMetadata metadata)
      throws IOException {
    GitPackEntity entity = new GitPackEntity();
    entity.setRepositoryName(repositoryName);
    entity.setPackName(stagedExtension.key().packName());
    entity.setPackExtension(stagedExtension.key().extension());
    entity.setFileSize(stagedExtension.fileSize());
    entity.setCommitted(true);
    entity.setCreatedAt(stagedExtension.createdAt());
    entity.setCommittedAt(committedAt);
    entity.setWriteToken(null);
    entity.setWriteLeaseUntil(null);
    metadata.applyTo(entity);

    boolean inline = stagedExtension.fileSize() <= HibernateObjDatabase.INLINE_PAYLOAD_THRESHOLD;
    byte[] inlineData = inline ? stagedExtension.inlineData() : null;
    entity.setData(inlineData);
    try {
      session.persist(entity);
      session.flush();
      if (!inline) {
        persistChunks(session, entity.getId(), stagedExtension);
      }
    } catch (RuntimeException exception) {
      if (isDuplicatePackExtension(exception)) {
        throw new IOException(
            "Pack extension already exists: " + stagedExtension.key().displayName(), exception);
      }
      throw exception;
    }
    return new CommittedExtension(
        stagedExtension.key().packName(),
        stagedExtension.key().extension(),
        entity.getId(),
        stagedExtension.fileSize(),
        inline,
        inlineData,
        metadata);
  }

  private static boolean isDuplicatePackExtension(Throwable failure) {
    for (Throwable current = failure; current != null; current = current.getCause()) {
      if (current instanceof ConstraintViolationException constraintViolation) {
        String constraintName = constraintViolation.getConstraintName();
        if (constraintName != null
            && constraintName
                .toLowerCase(Locale.ROOT)
                .contains(PACK_EXTENSION_UNIQUE_CONSTRAINT)) {
          return true;
        }
        if (isDuplicateSqlException(constraintViolation.getSQLException())) {
          return true;
        }
      }
      if (current instanceof SQLException sqlException && isDuplicateSqlException(sqlException)) {
        return true;
      }
    }
    return false;
  }

  private static boolean isDuplicateSqlException(SQLException exception) {
    for (SQLException current = exception; current != null; current = current.getNextException()) {
      String sqlState = current.getSQLState();
      if ("23505".equals(sqlState)
          || current.getErrorCode() == 2601
          || current.getErrorCode() == 2627) {
        return true;
      }
      String message = current.getMessage();
      if (message != null
          && message.toLowerCase(Locale.ROOT).contains(PACK_EXTENSION_UNIQUE_CONSTRAINT)) {
        return true;
      }
    }
    return false;
  }

  private void publishLegacyExtension(
      Session session,
      String packName,
      String extension,
      Instant committedAt,
      PackDescriptionMetadata metadata)
      throws IOException {
    int updated =
        session
            .createMutationQuery(
                "UPDATE GitPackEntity p SET p.committed = true, "
                    + "p.committedAt = :committedAt, p.writeToken = null, "
                    + "p.writeLeaseUntil = null, p.packSource = :packSource, "
                    + "p.lastModified = :lastModified, p.objectCount = :objectCount, "
                    + "p.deltaCount = :deltaCount, p.indexVersion = :indexVersion, "
                    + "p.minUpdateIndex = :minUpdateIndex, p.maxUpdateIndex = :maxUpdateIndex "
                    + "WHERE p.repositoryName = :repo AND p.packName = :name "
                    + "AND p.packExtension = :ext AND p.committed = false")
            .setParameter("committedAt", committedAt)
            .setParameter("packSource", metadata.packSource().name())
            .setParameter("lastModified", metadata.lastModified())
            .setParameter("objectCount", metadata.objectCount())
            .setParameter("deltaCount", metadata.deltaCount())
            .setParameter("indexVersion", metadata.indexVersion())
            .setParameter("minUpdateIndex", metadata.minUpdateIndex())
            .setParameter("maxUpdateIndex", metadata.maxUpdateIndex())
            .setParameter("repo", repositoryName)
            .setParameter("name", packName)
            .setParameter("ext", extension)
            .executeUpdate();
    if (updated != 1) {
      throw new IOException(
          "Cannot publish missing or already committed pack extension "
              + packName
              + "."
              + extension);
    }
  }

  private void persistChunks(
      Session session, Long packId, StagedExtension stagedExtension) throws IOException {
    long fileSize = stagedExtension.fileSize();
    long position = 0;
    int chunkIndex = 0;
    List<GitPackChunkEntity> pendingChunks = new ArrayList<>(CHUNK_BATCH_SIZE);
    try (HibernatePackChunkWriter chunkWriter = HibernatePackChunkWriter.open(session);
        StagedPayloadReader reader = stagedExtension.openReader()) {
      while (position < fileSize) {
        int chunkLength =
            (int) Math.min(HibernateObjDatabase.PACK_CHUNK_SIZE, fileSize - position);
        byte[] chunkData = new byte[chunkLength];
        ByteBuffer destination = ByteBuffer.wrap(chunkData);
        long chunkPosition = position;
        while (destination.hasRemaining()) {
          int count = reader.read(chunkPosition, destination);
          if (count <= 0) {
            throw new IOException("Staged pack payload ended before declared size " + fileSize);
          }
          chunkPosition += count;
        }

        GitPackChunkEntity chunk = new GitPackChunkEntity();
        chunk.setPackId(packId);
        chunk.setChunkIndex(chunkIndex);
        chunk.setChunkSize(chunkLength);
        chunk.setData(chunkData);
        pendingChunks.add(chunk);

        position += chunkLength;
        chunkIndex++;
        if (pendingChunks.size() == CHUNK_BATCH_SIZE) {
          chunkWriter.insert(pendingChunks);
          pendingChunks.clear();
        }
      }
      if (!pendingChunks.isEmpty()) {
        chunkWriter.insert(pendingChunks);
      }
    }
  }

  private static long stagedPayloadBytes(List<Publication> publications) {
    long total = 0;
    for (Publication publication : publications) {
      for (ExpectedExtension expected : publication.extensions()) {
        if (expected.staged() != null) {
          total = saturatingAdd(total, expected.staged().fileSize());
        }
      }
    }
    return total;
  }

  private static long committedPayloadBytes(List<CommittedExtension> extensions) {
    long total = 0;
    for (CommittedExtension extension : extensions) {
      total = saturatingAdd(total, extension.fileSize());
    }
    return total;
  }

  private static long persistedPayloadBytes(List<PersistedExtension> extensions) {
    long total = 0;
    for (PersistedExtension extension : extensions) {
      total = saturatingAdd(total, extension.staged().fileSize());
    }
    return total;
  }

  private void deletePreparedRows(Session session, Collection<String> writeTokens) {
    if (writeTokens.isEmpty()) {
      return;
    }
    session
        .createMutationQuery(
            "DELETE FROM GitPackEntity p WHERE p.repositoryName = :repo "
                + "AND p.committed = false AND p.writeToken IN :writeTokens")
        .setParameter("repo", repositoryName)
        .setParameter("writeTokens", writeTokens)
        .executeUpdate();
  }

  private void deletePackRows(Session session, Collection<String> packNames) {
    if (packNames.isEmpty()) {
      return;
    }
    session
        .createMutationQuery(
            "DELETE FROM GitPackEntity p WHERE p.repositoryName = :repo "
                + "AND p.packName IN :packNames")
        .setParameter("repo", repositoryName)
        .setParameter("packNames", packNames)
        .executeUpdate();
  }

  private static String baseName(DfsPackDescription description) {
    String fileName = description.getFileName(PackExt.PACK);
    int dot = fileName.lastIndexOf('.');
    return dot > 0 ? fileName.substring(0, dot) : fileName;
  }

  record CommitResult(List<CommittedExtension> committedExtensions, boolean completeMetadata) {
    CommitResult {
      committedExtensions = List.copyOf(committedExtensions);
    }
  }

  record CommittedExtension(
      String packName,
      String extension,
      Long packId,
      long fileSize,
      boolean inline,
      byte[] inlineData,
      PackDescriptionMetadata metadata) {
    CommittedExtension {
      if (inline != (inlineData != null)) {
        throw new IllegalArgumentException(
            "inline payload must be present exactly for inline rows");
      }
      metadata = Objects.requireNonNull(metadata, "metadata");
    }
  }

  private record PersistedExtension(
      StagedExtension staged,
      Long packId,
      boolean inline,
      byte[] inlineData,
      PackDescriptionMetadata metadata) {
    PersistedExtension {
      staged = Objects.requireNonNull(staged, "staged");
      packId = Objects.requireNonNull(packId, "packId");
      if (inline != (inlineData != null)) {
        throw new IllegalArgumentException(
            "inline payload must be present exactly for inline prepared rows");
      }
      metadata = Objects.requireNonNull(metadata, "metadata");
    }
  }

  private record ExtensionKey(String packName, String extension) {
    private String displayName() {
      return packName + "." + extension;
    }
  }

  private record ExpectedExtension(String extension, StagedExtension staged) {}

  private record Publication(
      String packName, DfsPackDescription description, List<ExpectedExtension> extensions) {}

  @FunctionalInterface
  interface PublicationTransaction {
    CommitResult execute(HibernateTransactionContext.Work<CommitResult> work, LongConsumer observer)
        throws IOException;

    default CommitResult execute(HibernateTransactionContext.Work<CommitResult> work)
        throws IOException {
      return execute(work, null);
    }
  }

  @FunctionalInterface
  interface PrePublicationHook {
    void afterPayloadPersisted(String writeToken) throws IOException;
  }

  @FunctionalInterface
  private interface StagingConsumer {
    void accept(StagedExtension extension) throws IOException;
  }

  private static final class StagedExtension {
    private final ExtensionKey key;
    private final StagedPayload payload;
    private final long fileSize;
    private final Instant createdAt;

    private StagedExtension(
        ExtensionKey key, StagedPayload payload, long fileSize, Instant createdAt) {
      this.key = key;
      this.payload = payload;
      this.fileSize = fileSize;
      this.createdAt = createdAt;
    }

    private ExtensionKey key() {
      return key;
    }

    private long fileSize() {
      return fileSize;
    }

    private Instant createdAt() {
      return createdAt;
    }

    private byte[] inlineData() throws IOException {
      return payload.inlineData();
    }

    private StagedPayloadReader openReader() throws IOException {
      return payload.openReader();
    }

    private boolean memoryBacked() {
      return payload.memoryBacked();
    }

    private void discard() {
      payload.discard();
    }
  }
}
