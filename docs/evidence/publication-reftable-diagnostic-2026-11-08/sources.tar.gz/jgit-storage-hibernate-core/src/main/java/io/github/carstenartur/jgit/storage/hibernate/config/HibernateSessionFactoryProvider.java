/*
 * Copyright (C) 2026, Carsten Hammer and contributors.
 *
 * This program and the accompanying materials are made available under the
 * terms of the BSD 3-Clause License.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
package io.github.carstenartur.jgit.storage.hibernate.config;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Properties;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.OracleDialect;

/** Provides a Hibernate {@link SessionFactory} configured for core JGit database storage. */
public final class HibernateSessionFactoryProvider implements AutoCloseable {

  private final SessionFactory sessionFactory;

  public HibernateSessionFactoryProvider(Properties properties) {
    this(properties, List.of());
  }

  public HibernateSessionFactoryProvider(
      Properties properties, Collection<Class<?>> additionalAnnotatedClasses) {
    Objects.requireNonNull(properties, "properties");
    Objects.requireNonNull(additionalAnnotatedClasses, "additionalAnnotatedClasses");

    Properties effectiveProperties = new Properties();
    effectiveProperties.putAll(properties);
    configureOracleDialect(effectiveProperties);
    int defaultJdbcBatchSize =
        hasText(effectiveProperties, HibernateStorageSettings.PACK_CHUNK_BATCH_SIZE)
            ? HibernateStorageSettings.resolvePackChunkBatchSize(effectiveProperties)
            : HibernateStorageSettings.DEFAULT_JDBC_BATCH_SIZE;
    effectiveProperties.putIfAbsent(
        HibernateStorageSettings.JDBC_BATCH_SIZE, Integer.toString(defaultJdbcBatchSize));
    effectiveProperties.putIfAbsent(
        HibernateStorageSettings.ORDER_INSERTS, Boolean.TRUE.toString());

    Configuration configuration = new Configuration();
    configuration.addProperties(effectiveProperties);
    for (Class<?> annotatedClass : CoreEntities.annotatedClasses()) {
      configuration.addAnnotatedClass(annotatedClass);
    }
    for (Class<?> annotatedClass : additionalAnnotatedClasses) {
      configuration.addAnnotatedClass(annotatedClass);
    }
    this.sessionFactory = configuration.buildSessionFactory();
  }

  public HibernateSessionFactoryProvider(SessionFactory sessionFactory) {
    this.sessionFactory = Objects.requireNonNull(sessionFactory, "sessionFactory");
  }

  public SessionFactory getSessionFactory() {
    return sessionFactory;
  }

  @Override
  public void close() {
    if (!sessionFactory.isClosed()) {
      sessionFactory.close();
    }
  }

  private static void configureOracleDialect(Properties properties) {
    Object dialect = properties.get("hibernate.dialect");
    if (OracleDialect.class.getName().equals(dialect) || dialect == OracleDialect.class) {
      properties.put("hibernate.dialect", JgitOracleDialect.class.getName());
    }
    // Hibernate runs discovered resolvers first, followed by configured resolvers in order.
    // Append our Oracle fallback so application resolvers keep their existing precedence.
    String resolver = JgitOracleDialectResolver.class.getName();
    String configured = properties.getProperty("hibernate.dialect_resolvers");
    properties.setProperty(
        "hibernate.dialect_resolvers",
        configured == null || configured.isBlank() ? resolver : configured + "," + resolver);
  }

  private static boolean hasText(Properties properties, String name) {
    Object value = properties.get(name);
    return value != null && !value.toString().isBlank();
  }
}
