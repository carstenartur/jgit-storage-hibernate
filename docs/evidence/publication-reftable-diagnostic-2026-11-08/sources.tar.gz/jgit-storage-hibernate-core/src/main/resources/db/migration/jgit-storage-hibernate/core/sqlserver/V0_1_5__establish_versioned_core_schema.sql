-- First migration owned and published with the 0.1.5 artifact line.
-- The physical schema is intentionally unchanged from 0.1.4.
select cast(1 as integer) as versioned_core_schema;
