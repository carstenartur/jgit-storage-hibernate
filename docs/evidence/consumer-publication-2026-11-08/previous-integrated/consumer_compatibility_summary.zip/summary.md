### Real-consumer compatibility

Candidate artifacts come from the exact library checkout under test. Scheduled baselines follow each declared default branch; pull-request and push baselines use the immutable pinned commit.

| Consumer | Source commit | Modules | Original → candidate | Candidate | Baseline | Contract |
|---|---|---|---|---:|---:|---|
| audio-analyzer | `18ca14d` | `jgit-storage-hibernate-core`, `jgit-storage-hibernate-search` | `0.11.8` → `0.12.1-SNAPSHOT` | passed (4m 17s) | passed (3m 47s) | audio-app reactor verification, dependency resolution and packaged-runtime leakage check |
| Taxonomy | `098aa05` | `jgit-storage-hibernate-core`, `jgit-storage-hibernate-smart-http` | `0.11.8` → `0.12.1-SNAPSHOT` | passed (6m 26s) | passed (3m 47s) | Core schema and Hibernate Search unit contracts plus PostgreSQL Testcontainers migration and validate-startup evidence |
| sandbox | `26391b1` | `jgit-storage-hibernate-core`, `jgit-storage-hibernate-java-analysis`, `jgit-storage-hibernate-search` | `0.11.8` → `0.12.1-SNAPSHOT` | passed (2m 52s) | passed (1m 48s) | Core-only OSGi bridge, released Search REST and Java project analysis contracts, legacy preflight, repository lifecycle and shaded-server packaging |

[Open retained compatibility artifacts and job logs](https://github.com/carstenartur/jgit-storage-hibernate/actions/runs/42425979963#artifacts)

The module list reports the pinned Maven contract. It is compatibility evidence, not a claim that these library microbenchmarks were measured inside the consuming application.
