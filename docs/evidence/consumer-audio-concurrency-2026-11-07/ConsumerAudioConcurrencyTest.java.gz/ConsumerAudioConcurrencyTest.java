/*
 * Copyright (C) 2026, Carsten Hammer and contributors.
 * SPDX-License-Identifier: BSD-3-Clause
 */
package io.github.carstenartur.jgit.storage.hibernate.benchmark;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ConsumerAudioConcurrencyTest {
  @Test
  void publishesAndVerifiesFourRepositoriesWithIndependentWorkerBatchCounters() throws Exception {
    var fixture = new ConsumerShapeBenchmark.Audio();
    fixture.coordinate = 262144;
    fixture.writer = "stateless";
    fixture.pressure = "bounded";
    fixture.chunkBatch = 8;
    fixture.repositories = 4;
    fixture.analysisMiB = 8;
    fixture.analysisWorkers = 2;
    try {
      fixture.setup();
      fixture.clear();
      var published = new ConsumerShapeBenchmark.Counters();
      new ConsumerShapeBenchmark().audioPublish(fixture, published);
      assertEquals(4 * 262144, published.payloadBytes);
      assertEquals(4, published.repositoriesProcessed);
      assertEquals(4, fixture.distinctWorkerThreads());
      assertEquals(4, published.jdbcBatches);
      assertTrue(published.databaseBytesWritten > published.payloadBytes);
      assertEquals(8L * 1024 * 1024, published.retainedAnalysisBytes);

      fixture.clear();
      var read = new ConsumerShapeBenchmark.Counters();
      new ConsumerShapeBenchmark().audioReadRecent(fixture, read);
      assertEquals(4 * 262144, read.payloadBytes);
      assertEquals(4, read.repositoriesProcessed);
      assertEquals(0, read.jdbcBatches);
    } finally {
      fixture.close();
    }
    assertEquals(0, fixture.activeAnalysisWorkers());
  }

  @Test
  void rejectsAnUnboundedRepositoryCountBeforeStartingWorkers() {
    var fixture = new ConsumerShapeBenchmark.Audio();
    fixture.repositories = 0;
    assertThrows(IllegalArgumentException.class, fixture::setup);
    assertEquals(0, fixture.activeAnalysisWorkers());
  }
}
